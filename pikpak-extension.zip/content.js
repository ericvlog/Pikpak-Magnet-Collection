console.log('[图片助手] Content script 已注入');

// ===== 全局错误捕获（抑制上下文失效错误） =====
window.addEventListener('unhandledrejection', function(event) {
    const msg = event.reason?.message || String(event.reason);
    if (msg.includes('Extension context invalidated') ||
        msg.includes('Extension context') ||
        msg.includes('message port closed') ||
        msg.includes('Could not establish connection')) {
        event.preventDefault();
        console.debug('[图片助手] 扩展上下文已失效，忽略此消息');
    }
});

document.documentElement.setAttribute('data-extension-installed', 'true');
window.postMessage({ type: 'EXTENSION_READY' }, '*');

// ===== 与后台通信的封装（带错误静默） =====
function sendMessageToBackground(message, callback) {
    try {
        chrome.runtime.sendMessage(message, (response) => {
            if (chrome.runtime.lastError) {
                const errMsg = chrome.runtime.lastError.message;
                if (errMsg.includes('Extension context invalidated') ||
                    errMsg.includes('message port closed')) {
                    // 静默忽略
                    return;
                }
                console.warn('[图片助手] 发送消息失败:', errMsg);
                if (callback) callback(null);
                return;
            }
            if (callback) callback(response);
        });
    } catch (e) {
        if (!e.message?.includes('Extension context')) {
            console.warn('[图片助手] 发送消息异常:', e);
        }
    }
}

// ===== Ping =====
sendMessageToBackground({ action: 'ping' }, (response) => {
    if (response) {
        console.log('[图片助手] ping 响应:', response);
        console.log('[图片助手] 后台通信正常');
    }
});

// ===== 监听外部预览触发 =====
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message?.type === 'SHOW_MAGNET_PREVIEW') {
        console.log('[图片助手] 收到外部预览触发:', message.magnet);
        if (message.magnet) {
            window.postMessage({ type: 'REQUEST_MAGNET_PREVIEW', magnet: message.magnet }, '*');
            sendResponse({ success: true });
        } else {
            sendResponse({ success: false, error: '缺少 magnet' });
        }
        return true;
    }
});

// ===== 监听页面消息 =====
window.addEventListener('message', (event) => {
    if (event.source !== window) return;

    // --- 图片下载（支持 referer） ---
    if (event.data.type === 'REQUEST_IMAGE_DOWNLOAD') {
        const url = event.data.url;
        const referer = event.data.referer || '';
        console.log('[图片助手] 收到下载请求:', url, 'Referer:', referer);

        sendMessageToBackground({ 
            action: 'downloadImage', 
            url: url,
            referer: referer
        }, (response) => {
            if (!response) {
                window.postMessage({ type: 'IMAGE_DOWNLOAD_RESULT', success: false, error: '后台未返回有效响应' }, '*');
                return;
            }
            if (response.success) {
                const byteCharacters = atob(response.data);
                const byteNumbers = new Array(byteCharacters.length);
                for (let i = 0; i < byteCharacters.length; i++) {
                    byteNumbers[i] = byteCharacters.charCodeAt(i);
                }
                const byteArray = new Uint8Array(byteNumbers);
                const blob = new Blob([byteArray], { type: response.contentType });
                window.postMessage({ type: 'IMAGE_DOWNLOAD_RESULT', success: true, blob: blob }, '*');
            } else {
                window.postMessage({ type: 'IMAGE_DOWNLOAD_RESULT', success: false, error: response.error || '未知错误' }, '*');
            }
        });
    }

    // --- 磁力预览请求 ---
    if (event.data.type === 'REQUEST_MAGNET_PREVIEW') {
        const magnet = event.data.magnet;
        console.log('[Content] 请求磁力预览:', magnet);
        sendMessageToBackground({ action: 'magnetPreview', magnet: magnet }, (response) => {
            window.postMessage({
                type: 'MAGNET_PREVIEW_RESULT',
                success: response?.success || false,
                data: response?.data,
                error: response?.error
            }, '*');
        });
    }

    // --- PikPak 离线 ---
    if (event.data.type === 'REQUEST_PIKPAK_OFFLINE') {
        const magnet = event.data.magnet;
        console.log('[Content] 收到 PikPak 离线请求:', magnet);

        sendMessageToBackground({ action: 'pikpakOffline', magnet: magnet }, (response) => {
            console.log('[Content] 收到 background 响应:', response);
            if (!response) {
                window.postMessage({
                    type: 'PIKPAK_OFFLINE_RESULT',
                    success: false,
                    error: '扩展未返回有效响应'
                }, '*');
                return;
            }
            window.postMessage({
                type: 'PIKPAK_OFFLINE_RESULT',
                success: response.success,
                data: response.data,
                error: response.error,
                code: response.code
            }, '*');
        });
    }

    // --- 获取待导入队列 ---
    if (event.data.type === 'REQUEST_PENDING_MAGNETS') {
        console.log('[Content] 收到待导入队列请求');
        sendMessageToBackground({ action: 'getPendingMagnets' }, (response) => {
            window.postMessage({
                type: 'PENDING_MAGNETS_RESULT',
                success: response?.success || false,
                data: response?.data || [],
                total: response?.total || 0,
                error: response?.error || null
            }, '*');
        });
    }

    // --- 清空待导入队列 ---
    if (event.data.type === 'REQUEST_CLEAR_PENDING_MAGNETS') {
        console.log('[Content] 收到清空队列请求');
        sendMessageToBackground({ action: 'clearPendingMagnets' }, (response) => {
            window.postMessage({
                type: 'CLEAR_PENDING_MAGNETS_RESULT',
                success: response?.success || false,
                error: response?.error || null
            }, '*');
        });
    }

    // ===== 新增：保存磁力到管理器（用于批量添加和预览窗） =====
    if (event.data.type === 'REQUEST_SAVE_MAGNET') {
        const { magnet, title, size, imageUrl } = event.data;
        console.log('[Content] 收到保存磁力请求:', magnet.substring(0, 40) + '...');
        sendMessageToBackground({
            action: 'saveMagnet',
            magnet: magnet,
            title: title || '',
            size: size || '',
            imageUrl: imageUrl || ''
        }, (response) => {
            window.postMessage({
                type: 'SAVE_MAGNET_RESULT',
                success: response?.success || false,
                error: response?.error || null
            }, '*');
        });
    }

    // ===== 新增：失败预览相关 =====
    if (event.data.type === 'REQUEST_FAILED_PREVIEWS') {
        console.log('[Content] 收到获取失败预览列表请求');
        sendMessageToBackground({ action: 'getFailedMagnets' }, (response) => {
            window.postMessage({
                type: 'FAILED_PREVIEWS_RESULT',
                success: response?.success || false,
                data: response?.data || [],
                total: response?.total || 0,
                error: response?.error || null
            }, '*');
        });
    }
    if (event.data.type === 'REQUEST_REMOVE_FAILED_PREVIEW') {
        const magnet = event.data.magnet;
        console.log('[Content] 收到删除失败预览请求:', magnet.substring(0, 40) + '...');
        sendMessageToBackground({ action: 'removeFailedMagnet', magnet: magnet }, (response) => {
            window.postMessage({
                type: 'REMOVE_FAILED_PREVIEW_RESULT',
                success: response?.success || false,
                error: response?.error || null
            }, '*');
        });
    }
    if (event.data.type === 'REQUEST_CLEAR_FAILED_PREVIEWS') {
        console.log('[Content] 收到清空失败预览列表请求');
        sendMessageToBackground({ action: 'clearFailedMagnets' }, (response) => {
            window.postMessage({
                type: 'CLEAR_FAILED_PREVIEWS_RESULT',
                success: response?.success || false,
                error: response?.error || null
            }, '*');
        });
    }
    if (event.data.type === 'REQUEST_SAVE_FAILED_MAGNET') {
        const { magnet, title } = event.data;
        console.log('[Content] 收到保存失败磁力请求:', magnet.substring(0, 40) + '...');
        sendMessageToBackground({
            action: 'saveFailedMagnet',
            magnet: magnet,
            title: title || ''
        }, (response) => {
            window.postMessage({
                type: 'SAVE_FAILED_MAGNET_RESULT',
                success: response?.success || false,
                error: response?.error || null
            }, '*');
        });
    }

    // ===== 新增：预览缓存（持久化） =====
    if (event.data.type === 'REQUEST_PREVIEWED_MAGNETS') {
        console.log('[Content] 收到获取已预览列表请求');
        sendMessageToBackground({ action: 'getPreviewedMagnets' }, (response) => {
            window.postMessage({
                type: 'PREVIEWED_MAGNETS_RESULT',
                success: response?.success || false,
                data: response?.data || [],
                error: response?.error || null
            }, '*');
        });
    }
    if (event.data.type === 'REQUEST_ADD_PREVIEWED_MAGNET') {
        const magnet = event.data.magnet;
        console.log('[Content] 收到添加已预览磁力请求:', magnet.substring(0, 40) + '...');
        sendMessageToBackground({ action: 'addPreviewedMagnet', magnet: magnet }, (response) => {
            window.postMessage({
                type: 'ADD_PREVIEWED_MAGNET_RESULT',
                success: response?.success || false,
                error: response?.error || null
            }, '*');
        });
    }
});